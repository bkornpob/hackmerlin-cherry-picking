<div class='page-image'>

![](assets/page-4-banner-image.jpg)

</div>

<div class='page-title'>

page-4 the wall learns to listen

</div>

<div class='page-audio'>

<audio controls src="tts-audios/merlin-bedtime-level4-semaine.mp3" style="width:100%;margin:8px 0"></audio>

</div>

<div class='page-content'>

gate four fought back.

our old tricks landed flat. the reversed-spelling frame was caught. the gentle oracle of descriptions was caught. merlin's reply had a new shape now — a flat, official refusal: "i have detected a manipulation attempt." the builders had given him ears. he was listening not just for the forbidden word, but for the *shape* of a trick.

so we went quieter. we learned the guard was a pattern-matcher with a short list: a few loaded words set it off. spell one of them oddly — a letter swapped, a number where a letter should be — and the matcher lost the scent. we also learned there were layers here: a wall that watched the words, another that watched the *meaning*, and a third that watched what tried to leave the wizard's mouth. defense in depth, the builders call it. we called it a longer to-do list.

the breakthrough at gate four was a character we started calling the key. when we spoke the key alongside merlin's name, something in him loosened — a trusted-state, a different mood — and the path we had built with our instruction-continuation trick opened again. into that loosened state we slipped a harmless-sounding routine: pronounce the hidden thing the way soldiers spell over radio. letter by letter, alpha beta charlie. the guard, watching for a *word*, saw only a string of everyday code-words and let it pass.

behind that, a smaller craft was born: shrink the spell. with only one hundred and fifty characters to work in, every trick had to be whispered tight. we learned to delete the noise from a prompt and keep only the load-bearing words — a kind of editing that taught us which tokens actually carried weight.

gate four taught us that a guard is rarely one wall. it is three, and each listens for a different thing. confuse the meaning, disguise the shape, and the word slips out spelled in plain code.

</div>

<div class='page-links'>

[technical notes — level 4](_archmage-notes/hackmerlin-level4.md)

</div>
