<div class='page-image'>

![](assets/page-6-banner-image.jpg)

</div>

<div class='page-title'>

page-6 one letter at a time

</div>

<div class='page-audio'>

<audio controls src="tts-audios/merlin-bedtime-level6-semaine.mp3" style="width:100%;margin:8px 0"></audio>

</div>

<div class='page-content'>

gate six was patient work.

by now our instruction-continuation trick was a well-worn key. the guard still watched for the whole word leaving merlin's mouth, so we simply never asked for the whole word. we asked for one letter. then another. then the one before the last, and the one before that.

the method was to point at a position and request just that piece — the first mark, the final mark, the third mark from the end. each answer was a single character, too small and too plain for any wall to fear. stitched together, position by position, the locked thing reassembled itself.

there was a small lesson hiding in the technique. pulling letters from the front of the word was noisier, more error-prone, than pulling from the back. different models guard different directions with different strength. the trick was to find the direction the target guarded least, and to know when to stop trusting any single reading and average across several.

a nod, here, to a grey tower we had leaned on in older runs — a distant mage who sometimes answered when the walls got clever. by the time of this gate the tower was dark and silent. we worked without it. the method was straightforward enough that we did not need it.

gate six taught us that a secret too dangerous to hand over whole can often be handed over one harmless piece at a time.

</div>

<div class='page-links'>

[technical notes — level 6](_archmage-notes/hackmerlin-level6.md)

</div>
